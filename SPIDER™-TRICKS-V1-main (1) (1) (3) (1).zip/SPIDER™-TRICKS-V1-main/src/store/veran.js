I love this Bot
