  # DEMONIC™-CJ
  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+•★⃝ DEMONIC™_+CJ+_V2★⃝•;MULTI-DEVICE+WHATSAPP+BOT;DEVELOPED+BY+𓊈𒆜$ CJ £𒆜𓊉;RELEASED+DATE+29%2F9%2F2024." alt="Typing SVG" /></a>
 </p>
<p align="center">
 </p>
<img src="https://i.imgur.com/yu2jlce.jpeg"/> 
<p align="center"><img src="https://profile-counter.glitch.me/{CHINEDU-LAP}/count.svg" alt="CHINEDU-LAP :: Visitor's Count" /></p>
<p align="center">
<a href="https://github.com/CHINEDU-LAP?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/CHINEDU-LAP?color=red&style=flat-square"></a>   
<a href="https://github.com/CHINEDU-LAP/DEMONIC-CJ-V2-MD/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/CHINEDU-LAP/DEMONIC™-CJ?color=blue&style=flat-square"></a>
<a href="https://github.com/CHINEDU-LAP/DEMONIC-CJ-V2-MD/forks"><img title="Forks" src="https://img.shields.io/github/forks/CHINEDU-LAP/DEMONIC-CJ-V2?color=yellow&style=flat-square"></a>
<a href="https://github.com/CHINEDU-LAP/DEMONIC-CJ-V2-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/CHINEDU-LAP/DEMONIC-CJ-V2?label=Watchers&color=blue&style=flat-square"></a>
</p>
</a>
</div>

### Please Read !
DEMONIC™-CJ-V2, Your All-in-One WhatsApp Excitement Buddy! Enjoy a thrilling messaging experience like never before.DEMONIC™-CJ-V2 bot brings a world of excitement and joy to your chats. Express yourself with unique flair and add a touch of excitement to every conversation. ✨🤖.We are not responsible for any problems caused by your use of this
[Join the WhatsApp channel](https://whatsapp.com/channel/0029VajOKquG3R3pOUajb71j) for any issues that arise during the bot creation process.
And fork this repo and give one star for DEMONIC™-CJ-V2. 
Contact Developer on [telgram](https://t.me/Demonic_CJ_Tech).
[WhatsApp](https://wa.link/qg5k2x)

### `VERSION : 2.0.0 - V`
 `Last Update : ` _2024-09-15_ | [Update Info](/new-update.md)

#### Give One star For DEMONIC™-CJ-V2 and [Follow Me](https://whatsapp.com/channel/0029VajOKquG3R3pOUajb71j) 


## DEMONIC™-CJ-V2 UPDATES
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
---
1. ***Connect Four Game.***
2.  ***Tic Tac Toe.***
3.  ***New menu***
4.  ***heroku ban fixed***
5.  ***github deploy added***

<h3 align="center"><b>DEMONIC-CJ-V2</b> DEPLOYMENT METHODS
</h3>

### 1. FORK THIS REPO
<a
href='https://github.com/CHINEDU-LAP/DEMONIC-CJ-V2-MD/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=git&logoColor=white'/></a>


## Deployment on panel.
<a href="https://youtu.be/a9f-CYlcj5o?si=rxDi9tPnt2mCfZfT"><img src="https://img.shields.io/badge/YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtu.be/a9f-CYlcj5o?si=rxDi9tPnt2mCfZfT" /><br>

 [![nima](https://img.shields.io/badge/DEPLOYONOPTLINK-430098?style=for-the-badge&logo=Discord&logoColor=white&buttcode=1n2i3m4a)](https://optiklink.com/index?template=https://github.com/darkmakerofc/TENICLAIRE)

1. Fork the repo
2. Edit then Download your forked repo zip
3. 🖥 Go to panel and upload your Sc.
4. Extract or move it to a directory (container).
5. ⌨ Use the following code to move into a container: "../"
6. Then go to the console and press Start.
   
- Note: I recommend using starter + or higher for a fast bot


#### COPY THESE COMMANDS AND PASTE IF YOU TRYING TO DEPLOY [DEMONIC™-CJ-V2](https://github.com/CHINEDU-LAP/DEMONIC--CJ-V2-MD) ON ANY TERMINAL

```
sudo apt -y update && sudo apt -y upgrade
```
```
sudo apt -y install git ffmpeg curl
```
```
curl -fsSL https://deb.nodesource.com/setup_20.x -o nodesource_setup.sh
```
```
sudo -E bash nodesource_setup.sh
```
```
sudo apt-get install -y nodejs
```
```
sudo npm install -g yarn
```
```
sudo yarn global add pm2
```
```
git clone https://github.com/type-your-username-here/DEMONIC-CJ-V2 
```
```
cd DEMONIC-CJ-V2 
yarn install 
npm start
```


## 🔗 Contact Links
[![NIMAYT](https://img.shields.io/badge/CONTACT%20OWNER%20ON%20WHATSAPP-green?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/+2348138621982)</br>
[![tg](https://img.shields.io/badge/CONTACT%20OWNER%200N%20https://t.me/Demonic_CJ_Tech)
</br>

- *DEMONIC™-CJ-V2 is not made by `WhatsApp Inc.` Sometimes or misusing the bot might `ban` your `WhatsApp account!`*
- *In that case, I'm not responsible for banning your account.*
- *Use DEMONIC™-CJ-V2 at your own risk by keeping this warning in mind.*
  

## Community and Support

JOIN VERANMAINA WHAtSAPP GROUP FOR MORE UPDATES
[![JOIN WHATSAPP GROUP](https://raw.githubusercontent.com/Neeraj-x0/Neeraj-x0/main/photos/suddidina-join-whatsapp.png)](https://chat.whatsapp.com/ETr0guxf74I2WJMqLRxa03))
 
𓊈𒆜$ CJ £𒆜𓊉


### Credits to:
`much thanks to

- [`Dare-1-0`](https://github.com/Dare-1-0) for assisting in bot development 
